package com.nextlevelgaming.arena

import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

data class Offer(
    val name: String,
    val price: Double,
    val description: String,
    val included: List<String>
)

class MainActivity : AppCompatActivity() {

    private lateinit var content: LinearLayout
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private val selectedOffers = ArrayList<Offer>()

    private val offers = listOf(
        Offer("Ultimate Gamer Pass", 1500.0,
            "Unlimited gaming access for a full day.",
            listOf("PC gaming", "Console gaming", "High-speed internet", "Snack voucher", "Tournament entry")),
        Offer("VIP Gaming Experience", 1500.0,
            "Premium gaming experience with exclusive facilities.",
            listOf("Private gaming booth", "Premium gaming equipment", "Food and drinks", "Priority booking", "Personal gaming assistant")),
        Offer("Esports Training Package", 1500.0,
            "Improve competitive gaming skills with professional coaching.",
            listOf("Strategy coaching", "Team communication", "Match analysis", "Practice sessions", "Performance feedback")),
        Offer("Birthday Party Package", 1500.0,
            "Host a gaming-themed birthday celebration.",
            listOf("Reserved gaming area", "Multiplayer competitions", "Party decorations", "Catering", "Tournament prizes")),
        Offer("Virtual Reality Experience", 750.0,
            "Explore immersive virtual reality games.",
            listOf("VR headset", "Choice of games", "Staff assistance")),
        Offer("Racing Simulator Challenge", 750.0,
            "Race on professional driving simulators.",
            listOf("Racing simulator", "Choice of tracks", "Leaderboard competition")),
        Offer("Escape Room Challenge", 750.0,
            "Solve puzzles and escape before time runs out.",
            listOf("Team challenge", "Themed escape room", "Digital scorecard"))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        content = findViewById(R.id.contentLayout)
        title = findViewById(R.id.pageTitle)
        subtitle = findViewById(R.id.pageSubtitle)

        val spinner = findViewById<Spinner>(R.id.menuSpinner)
        val pages = arrayOf(
            "Home", "About Us", "Packages & Experiences",
            "Calculate Total Fees", "Contact Us"
        )
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, pages)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                when (pages[position]) {
                    "Home" -> showHome()
                    "About Us" -> showAbout()
                    "Packages & Experiences" -> showPackages()
                    "Calculate Total Fees" -> showCalculator()
                    "Contact Us" -> showContact()
                }
            }
        }
    }

    private fun clearPage(pageTitle: String, pageSubtitle: String) {
        title.text = pageTitle
        subtitle.text = pageSubtitle
        content.removeAllViews()
    }

    private fun addText(value: String, size: Float = 15f, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = value
        t.textSize = size
        t.setTextColor(getColor(if (bold) R.color.white else R.color.muted))
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD)
        t.setPadding(0, 12, 0, 12)
        content.addView(t)
        return t
    }

    private fun addButton(label: String, action: () -> Unit) {
        val b = Button(this)
        b.text = label
        b.setOnClickListener { action() }
        content.addView(b)
    }

    private fun showHome() {
        clearPage("PLAY. COMPETE. LEVEL UP.", "Johannesburg's high-energy gaming and esports arena.")
        addText("Gaming events • Esports tournaments • Birthday parties • School outings • Corporate team building")
        addText("Modern gaming technology, competitive experiences and social entertainment.", 16f, true)
        addButton("EXPLORE PACKAGES") { showPackages() }
        addButton("CALCULATE FEES") { showCalculator() }
    }

    private fun showAbout() {
        clearPage("ABOUT NEXT LEVEL", "Modern entertainment for gamers and groups.")
        addText("Next Level Gaming & Esports Arena was established in 2023 by Jason Naidoo and operates in Johannesburg.", 16f)
        addText("VISION", 14f, true)
        addText("A high-energy space where gamers can connect, compete and have fun.")
        addText("MISSION", 14f, true)
        addText("Deliver memorable experiences for individuals, families, schools, gaming clubs and businesses.")
        addText("GOALS", 14f, true)
        addText("Provide access to gaming technology, organised events and enjoyable gaming experiences.")
    }

    private fun showPackages() {
        clearPage("PACKAGES & EXPERIENCES", "Select an offering to view its details.")
        offers.forEach { offer ->
            addButton("${offer.name} - R${offer.price.toInt()}") {
                showOffer(offer)
            }
        }
    }

    private fun showOffer(offer: Offer) {
        clearPage(offer.name, "R${offer.price.toInt()}")
        addText(offer.description, 16f)
        addText("INCLUDES", 14f, true)
        offer.included.forEach { addText("✓ $it") }
        addButton("ADD TO FEE CALCULATOR") { showCalculator() }
    }

    private fun showCalculator() {
        clearPage("CALCULATE TOTAL FEES", "Select bookings. Discount: 1=0%, 2=5%, 3=10%, 4+=15%. VAT = 15%.")

        val name = EditText(this)
        name.hint = "Customer name"
        content.addView(name)

        val phone = EditText(this)
        phone.hint = "Phone number"
        phone.inputType = InputType.TYPE_CLASS_PHONE
        content.addView(phone)

        val email = EditText(this)
        email.hint = "Email address"
        email.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        content.addView(email)

        val checks = ArrayList<CheckBox>()
        offers.forEach { offer ->
            val check = CheckBox(this)
            check.text = "${offer.name} - R${offer.price.toInt()}"
            content.addView(check)
            checks.add(check)
        }

        val result = addText("Total: R0.00", 18f, true)

        addButton("CALCULATE TOTAL") {
            if (name.text.toString().trim().isEmpty() ||
                phone.text.toString().trim().isEmpty() ||
                email.text.toString().trim().isEmpty()) {
                Toast.makeText(this, "Please enter your name, phone and email.", Toast.LENGTH_LONG).show()
                return@addButton
            }

            selectedOffers.clear()
            checks.forEachIndexed { index, check ->
                if (check.isChecked) selectedOffers.add(offers[index])
            }

            if (selectedOffers.isEmpty()) {
                Toast.makeText(this, "Please select at least one booking.", Toast.LENGTH_LONG).show()
                return@addButton
            }

            val subtotal = selectedOffers.sumOf { it.price }
            val discountRate = when (selectedOffers.size) {
                1 -> 0.0
                2 -> 0.05
                3 -> 0.10
                else -> 0.15
            }
            val discount = subtotal * discountRate
            val afterDiscount = subtotal - discount
            val vat = afterDiscount * 0.15
            val total = afterDiscount + vat

            result.text = "Subtotal: R%.2f\nDiscount: %.0f%%\nVAT 15%%: R%.2f\nTOTAL: R%.2f"
                .format(subtotal, discountRate * 100, vat, total)
        }

        addButton("REQUEST CONSULTANT") {
            Toast.makeText(this, "Thank you. A consultant will contact you.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showContact() {
        clearPage("CONTACT US", "Plan your next gaming session or event.")
        addText("Phone: +27 10 000 0000")
        addText("Email: info@nextlevelgaming.co.za")
        addText("Social: Instagram • Facebook • TikTok")
        addText("Venue: Johannesburg, Gauteng")
        addText("Map: Johannesburg venue location")
        addButton("REQUEST A CONSULTANT") { showCalculator() }
    }
}
